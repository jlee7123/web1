<template>

 <v-container>
    <CreateRS/>
  </v-container>

</template>

<script>
import CreateRS from '../components/createRS.vue'

  export default {
    name: 'Home',
    components: {
    CreateRS,
},

    data () {
      return {
        
        color: '#FF4081',
         myStyle:{
            backgroundColor:"#white" 
            },
        right: true,
        permanent: true,
        miniVariant: true,
        expandOnHover: true,
        background: false
        ,
      }
    },



  }
</script>
