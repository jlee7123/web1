<template>
  <b-container>
    <h2 class="text-center">oneM2M Resource Creation</h2>
    <br><br>

    <h5><b> &nbsp;&nbsp;URL</b></h5>
    <b-col>
      <label for="input-live">Platform Address:</label>
      <b-form-input
        id="Platform"
        v-model="data_obj.Platform_addr"
        :state="data_obj.Platform_addr.length >= 9"
        placeholder="Enter Platform Address"
        trim
      ></b-form-input>
    </b-col>

    <b-row>
      <b-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          elevation="2"
          v-on:click="ae_form"
        >
          AE
        </v-btn>
      </b-col>
      <b-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          elevation="2"
          v-on:click="cnt_form"
        >
          Container
        </v-btn>
      </b-col>
      <b-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          elevation="2"
          v-on:click="cin_form"
        >
          Content Instance</v-btn
        >
      </b-col>
      <b-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          elevation="2"
          v-on:click="sub_form"
        >
          Subscription</v-btn
        >
      </b-col>
    </b-row>
    <br>
 
<!-- AE -->
    <v-card  v-if="(selected==='ae')" class="pa-10" outlined shaped elevation="3">
      <h3>oneM2M Request Primitive Parameters - AE</h3>
      <v-row>
        <v-col>
          <v-card class="pa-1" shaped elevation="0">
            <h3> &nbsp; </h3>
            <b-col>
              <label for="input-live">To (to): String</label>
              <b-form-input
                id="resid"
                v-model="data_obj.Res_Id"
                :state="data_obj.Res_Id.length >= 3"
                placeholder="Enter Resource ID (TO)"
                trim
              ></b-form-input>
              <br>
              <label for="input-live">From (from): String</label>
              <b-form-input
                id="xm2morigin"
                v-model="data_obj.X_M2M_Origin"
                :state="data_obj.X_M2M_Origin.length >= 1"
                placeholder="Enter X-M2M Origin"
                trim
              ></b-form-input>
              <br>
              <label for="input-live">Request ID (rqi): String </label>
              <b-form-input
                id="xm2mri"
                v-model="data_obj.X_M2M_RI"
                :state="data_obj.X_M2M_RI.length >= 4"
                placeholder="Enter X-M2M RI"
                trim
              ></b-form-input>
              <br />
            </b-col>
          </v-card>
        </v-col>


        <v-col>
          <h5>Primitive Content (pc):</h5>
          <v-card class="pa-3" outlined shaped elevation="1">
            <b-col>
              <label for="input-live">Resource Name (rn): String</label>
              <b-form-input
                id="res_name"
                v-model="res_name"
                :state="res_name.length >= 0"
                ref="res_name"
                @change="change"
                placeholder="Enter resource name (rn)"
                trim
              ></b-form-input>

              <br />

              <label for="input-live">Labels (lbl): Array of String</label>
              <b-form-input
                id="xm2mlbl"
                v-model="data_obj.lbl"
                :state="data_obj.lbl.length >= 0"
                placeholder="Enter labels (lbl)"
                trim
              ></b-form-input>
              <br />

              <label for="input-live">app ID (api): String</label>
              <b-form-input
                id="xm2mapi"
                v-model="data_obj.api"
                :state="data_obj.api.length >= 0"
                ref="xm2mapi"
                @change="change"
                placeholder="Enter app ID (api)"
                trim
              ></b-form-input>
              <br />
              <label for="input-live">AE-ID (aei): String (starts with "s" or "C")</label>
              <b-form-input
                id="xm2maei"
                v-model="data_obj.aei"
                :state="data_obj.aei.length >= 0"
                ref="xm2maei"
                @change="change"
                placeholder="Enter AE-ID (aei)"
                trim
              ></b-form-input>
              <br />
              <label for="input-live">request reachability (rr): Boolean</label>
              <b-form-input
                id="xm2mrr"
                v-model="data_obj.rr"
                :state="res_name.length >= 0"
                ref="xm2mrr"
                @change="change"
                placeholder="Enter request reachability (rr)"
                trim
              ></b-form-input>
              <br />
            </b-col>
          </v-card>
        </v-col>
      </v-row>

    </v-card>


    <!-- v-card CNT -->
        <v-card  v-if="(selected==='cnt')" class="pa-10" outlined shaped elevation="3">
      <h3>oneM2M Request Primitive Parameters - CNT</h3>
      <v-row>
        <v-col>
          <v-card class="pa-1" shaped elevation="0">
            <h3> &nbsp; </h3>
            <b-col>
              <label for="input-live">To (to): String</label>
              <b-form-input
                id="resid"
                v-model="data_obj.Res_Id"
                :state="data_obj.Res_Id.length >= 3"
                placeholder="Enter Resource ID (TO)"
                trim
              ></b-form-input>
              <br />
              <label for="input-live">From (from): String</label>
              <b-form-input
                id="xm2morigin"
                v-model="data_obj.X_M2M_Origin"
                :state="data_obj.X_M2M_Origin.length >= 1"
                placeholder="Enter X-M2M Origin"
                trim
              ></b-form-input>
              <br />
              <label for="input-live">Request ID (rqi): String </label>
              <b-form-input
                id="xm2mri"
                v-model="data_obj.X_M2M_RI"
                :state="data_obj.X_M2M_RI.length >= 4"
                placeholder="Enter X-M2M RI"
                trim
              ></b-form-input>
              <br />
            
              <br />
            </b-col>
          </v-card>
        </v-col>

        <v-col>
          <h5>Primitive Content (pc):</h5>
          <v-card class="pa-3" outlined shaped elevation="1">
            <b-col>
              <label for="input-live">Resource Name (rn): String</label>
              <b-form-input
                id="res_name"
                v-model="res_name"
                :state="res_name.length >= 0"
                ref="res_name"
                @change="change"
                placeholder="Enter resource name (rn)"
                trim
              ></b-form-input>

              <br />

              <label for="input-live">Labels (lbl): Array of String</label>
              <b-form-input
                id="xm2mlbl"
                v-model="data_obj.lbl"
                :state="data_obj.lbl.length >= 0"
                placeholder="Enter labels (lbl)"
                trim
              ></b-form-input>
              <br />

              <label for="input-live"
                >Maximum Number of Instances(mni): Integer</label
              >
              <b-form-input
                id="xm2mmni"
                v-model="data_obj.mni"
                :state="data_obj.mni.length >= 0"
                placeholder="Enter max number of instances (mni)"
                trim
              ></b-form-input>
              <br />

              <label for="input-live"
                >Maximum Number of Byte Size (mbs): Integer</label
              >
              <b-form-input
                id="xm2mmbs"
                v-model="data_obj.mbs"
                :state="data_obj.mbs.length >= 0"
                placeholder="Enter max number of byte size (mbs)"
                trim
              ></b-form-input>
              <br />
            </b-col>
          </v-card>
        </v-col>
      </v-row>
    </v-card>

    <!-- v-card CIN -->
        <v-card  v-if="(selected==='cin')" class="pa-10" outlined shaped elevation="3">
      <h3>oneM2M Request Primitive Parameters - CIN</h3>
      <v-row>
        <v-col>
          <v-card class="pa-1" shaped elevation="0">
            <h3> &nbsp; </h3>
            <b-col>
              <label for="input-live">To (to): String</label>
              <b-form-input
                id="resid"
                v-model="data_obj.Res_Id"
                :state="data_obj.Res_Id.length >= 3"
                placeholder="Enter Resource ID (TO)"
                trim
              ></b-form-input>
              <br />
              <label for="input-live">From (from): String</label>
              <b-form-input
                id="xm2morigin"
                v-model="data_obj.X_M2M_Origin"
                :state="data_obj.X_M2M_Origin.length >= 1"
                placeholder="Enter X-M2M Origin"
                trim
              ></b-form-input>
              <br />
              <label for="input-live">Request ID (rqi): String </label>
              <b-form-input
                id="xm2mri"
                v-model="data_obj.X_M2M_RI"
                :state="data_obj.X_M2M_RI.length >= 4"
                placeholder="Enter X-M2M RI"
                trim
              ></b-form-input>
              <br />

              <br />
            </b-col>
          </v-card>
        </v-col>

        <v-col>
          <h5>Primitive Content (pc):</h5>
          <v-card class="pa-3" outlined shaped elevation="1">
            <b-col>
              <label for="input-live">Resource Name (rn): String</label>
              <b-form-input
                id="res_name"
                v-model="res_name"
                :state="res_name.length >= 0"
                ref="res_name"
                @change="change"
                placeholder="Enter resource name (rn)"
                trim
              ></b-form-input>

              <br />

              <label for="input-live">Labels (lbl): Array of String</label>
              <b-form-input
                id="xm2mlbl"
                v-model="data_obj.lbl"
                :state="data_obj.lbl.length >= 0"
                placeholder="Enter labels (lbl)"
                trim
              ></b-form-input>
              <br />
              <label for="input-live">Content (con): Any</label>
              <b-form-input
                id="cin_con"
                v-model="data_obj.con"
                :state="data_obj.con.length >= 0"
                ref="cin_con"
                @change="change"
                placeholder="Enter content (con)"
                trim
              ></b-form-input>
              <br />

            </b-col>


          </v-card>
        </v-col>
      </v-row>
    </v-card>

<!-- SUB -->
        <v-card  v-if="(selected==='sub')" class="pa-10" outlined shaped elevation="3">
      <h3>oneM2M Request Primitive Parameters - SUB</h3>
      <v-row>
        <v-col>
          <v-card class="pa-1" shaped elevation="0">
            <h3> &nbsp; </h3>
            <b-col>
              <label for="input-live">To (to): String</label>
              <b-form-input
                id="resid"
                v-model="data_obj.Res_Id"
                :state="data_obj.Res_Id.length >= 3"
                placeholder="Enter Resource ID (TO)"
                trim
              ></b-form-input>
              <br />
              <label for="input-live">From (from): String</label>
              <b-form-input
                id="xm2morigin"
                v-model="data_obj.X_M2M_Origin"
                :state="data_obj.X_M2M_Origin.length >= 1"
                placeholder="Enter X-M2M Origin"
                trim
              ></b-form-input>
              <br />
              <label for="input-live">Request ID (rqi): String </label>
              <b-form-input
                id="xm2mri"
                v-model="data_obj.X_M2M_RI"
                :state="data_obj.X_M2M_RI.length >= 4"
                placeholder="Enter X-M2M RI"
                trim
              ></b-form-input>
              <br />

              <br />
            </b-col>
          </v-card>
        </v-col>

        <v-col>
          <h5>Primitive Content (pc):</h5>
          <v-card class="pa-3" outlined shaped elevation="1">
            <b-col>
              <label for="input-live">Resource Name (rn): String</label>
              <b-form-input
                id="res_name"
                v-model="res_name"
                :state="res_name.length >= 0"
                ref="res_name"
                @change="change"
                placeholder="Enter resource name (rn)"
                trim
              ></b-form-input>

              <br />

              <label for="input-live">Labels (lbl): Array of String</label>
              <b-form-input
                id="xm2mlbl"
                v-model="data_obj.lbl"
                :state="data_obj.lbl.length >= 0"
                placeholder="Enter labels (lbl)"
                trim
              ></b-form-input>
              <br />


              <label for="input-live">NotificationURI (nu): String</label>
              <b-form-input
                id="sub_nu"
                v-model="data_obj.nu"
                :state="data_obj.nu.length >= 0"
                placeholder="Enter notificationURI (nu)"
                trim
              ></b-form-input>

              <br />

              <label for="input-live">EventNotificationCriteria (enc): Array of Integer</label>
              <b-form-input
                id="sub_enc"
                v-model="data_obj.enc"
                :state="data_obj.enc.length >= 0"
                placeholder="Enter EventNotificationCriteria (enc)"
                trim
              ></b-form-input>
              <br />

              
            </b-col>
          </v-card>
        </v-col>
      </v-row>
    </v-card>
    <br />



<!--AE 선택시 HTTP Request 버튼 -->
    <v-row v-if="(selected==='ae')">
      <v-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          elevation="2"
          @click="ae_print"
        >
          [AE] HTTP REQUEST
        </v-btn>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          elevation="2"
          disabled
          @click="cin_print"
        >
          [CIN] HTTP REQUEST</v-btn
        >
      </v-col>
      <v-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="cnt_print"
        >
          [CNT] HTTP REQUEST
        </v-btn>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="sub_print"
        >
          [SUB] HTTP REQUEST</v-btn
        >
      </v-col>
    </v-row>

<!--CNT 선택시 HTTP Request 버튼 -->
    <v-row v-if="(selected==='cnt')">
      <v-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="ae_print"
        >
          [AE] HTTP REQUEST
        </v-btn>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="cin_print"
        >
          [CIN] HTTP REQUEST</v-btn
        >
      </v-col>
      <v-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          elevation="2"
          @click="cnt_print"
        >
          [CNT] HTTP REQUEST
        </v-btn>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="sub_print"
        >
          [SUB] HTTP REQUEST</v-btn
        >
      </v-col>
    </v-row>

    <!--CIN 선택시 HTTP Request 버튼 -->
    <v-row v-if="(selected==='cin')">
      <v-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="ae_print"
        >
          [AE] HTTP REQUEST
        </v-btn>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          elevation="2"
          @click="cin_print"
        >
          [CIN] HTTP REQUEST</v-btn
        >
      </v-col>
      <v-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="cnt_print"
        >
          [CNT] HTTP REQUEST
        </v-btn>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="sub_print"
        >
          [SUB] HTTP REQUEST</v-btn
        >
      </v-col>
    </v-row>

    <!--sub 선택시 HTTP Request 버튼 -->
    <v-row v-if="(selected==='sub')">
      <v-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="ae_print"
        >
          [AE] HTTP REQUEST
        </v-btn>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="cin_print"
        >
          [CIN] HTTP REQUEST</v-btn
        >
      </v-col>
      <v-col>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          disabled
          elevation="2"
          @click="cnt_print"
        >
          [CNT] HTTP REQUEST
        </v-btn>
        <v-btn
          class="ma-1"
          color="deep-purple"
          block
          outlined
          raised
          rounded
          elevation="2"
          @click="sub_print"
        >
          [SUB] HTTP REQUEST</v-btn
        >
      </v-col>
    </v-row>


    <br />
    <v-btn
      class="ma-1"
      color="#EDE7F6"
      block
      raised
      rounded
      elevation="2"
      @click="post_request"
    >
      SEND Request
    </v-btn>
    <br /><br />

    <v-card class="pa-10" outlined shaped elevation="2">
      <v-row>
        <b-col sm="6" md="5" offset-md="2" lg="6" offset-lg="0">
          <h5>HTTP Request</h5>
          <b-card shadow="always">
            <b>Request-Line</b>
            <br />
            {{data_obj.Create_text}} 
            {{ "http://" + data_obj.Platform_addr +"/" + data_obj.Res_Id }}
            <br />
            <br />

            <div>
              <b>Header</b>
              <b-table
                ref="reqtable"
                style="font-size: 0.9rem"
                small
                stacked
                :items="req_items"
                :fields="req_fields"
              >
              </b-table>
              <h5>&nbsp;</h5>
              <b>Body</b>

              <b-form-textarea
                style="font-size: 0.8rem"
                id="textreq"
                v-model="request_text"
                rows="10"
                max-rows="20"
              ></b-form-textarea>
            </div>
          </b-card>
          <br />
        </b-col>
        <br />

        <b-col sm="6" md="5" offset-md="2" lg="6" offset-lg="0">
          <h5>HTTP Response</h5>
          <b-card shadow="always">
            <b>Status-Line</b>
            <br />
            {{ this.res_status }}
            <br />
            <br />
            <div>
              <b>Header</b>
              <b-table
                ref="restable"
                style="font-size: 0.9rem"
                small
                stacked
                :items="res_items"
                :fields="res_fields"
              >
              </b-table>
              <b>Body</b> 
              <b-form-textarea
                style="font-size: 0.8rem"
                id="textres"
                v-model="response_text"
                rows="10"
                max-rows="20"
              ></b-form-textarea>
            </div>
          </b-card>
        </b-col>

        <br />
      </v-row>
    </v-card>
  </b-container>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      selected: 'ae',
      res_name: "",
      data_obj: {
        Create_text: 'POST',
        Platform_addr: "203.253.128.177:7579",
        Res_Id: "Mobius/MUV/approval",
        X_M2M_RI: "12345",
        X_M2M_Origin: "SOrigin",
        Accept: "application/json",

        lbl: "",
        mni: "",
        mbs: "",
        ty: "",
        op: "",
        api: "",
        aei: "",
        rr: "",
        con: "",
        nu: "",
        enc: "",

      },
      req_fields: [
        { key: "X-M2M-RI", class: "text-center" },
        { key: "X-M2M-Origin", class: "text-center" },
        { key: "Content-Type", class: "text-center" },
        { key: "Accept", class: "text-center" },
      ],
      req_items: [
        { "X-M2M-RI": "", "X-M2M-Origin": "", "Content-Type": "", Accept: "" },
      ],
      res_fields: [
        { key: "X-M2M-RI", class: "text-center" },
        { key: "X-M2M-RSC", class: "text-center" },
        { key: "X-M2M-RVI", class: "text-center" },
        { key: "Content-Length", class: "text-center" },
        { key: "Content-Type", class: "text-center" },
      ],
      res_items: [
        {
          "X-M2M-RI": "",
          "X-M2M-RSC": "",
          "X-M2M-RVI": "",
          "Content-Length": "",
          "Content-Type": "",
        },
      ],
      headers_text: "",
      request_text: "",
      response_text: "",
      res_mess: "",
      res_errmess: "",
      res_status: "",
    };
  },
  methods: 
  {
      ae_form(){
      this.selected='ae';
      this.flag1=true;
      this.flag2=false;
    },
      cnt_form(){
      this.selected='cnt';
      this.flag1=false;
      this.flag2=true;
    },
      cin_form(){
      this.selected='cin';
      this.flag1=false;
      this.flag2=true;
    },
      sub_form(){
      this.selected='sub';
      this.flag1=false;
      this.flag2=true;
    },

    request_header_change(obj) {
      console.log(obj);
      this.req_items[0]["X-M2M-RI"] = obj["X-M2M-RI"];
      this.req_items[0]["X-M2M-Origin"] = obj["X-M2M-Origin"];
      this.req_items[0]["Content-Type"] = obj["Content-Type"];
      this.req_items[0]["Accept"] = obj["Accept"];
      this.$refs.reqtable.refresh();
    },
    response_header_change(obj) {
      console.log(obj);
      this.res_items[0]["X-M2M-RI"] = obj["X-M2M-RI"];
      this.res_items[0]["X-M2M-RSC"] = obj["X-M2M-RSC"];
      this.res_items[0]["X-M2M-RVI"] = obj["X-M2M-RVI"];
      this.res_items[0]["Content-Length"] = obj["Content-Length"];
      this.res_items[0]["Content-Type"] = obj["Content-Type"];
      this.$refs.restable.refresh();
    },
    ae_print() {
      let ae_obj = {};
      ae_obj["m2m:ae"] = {};
      //ae_obj["m2m:ae"].rn = "ae_test";
      ae_obj["m2m:ae"].rn = this.res_name;
      ae_obj["m2m:ae"].lbl = JSON.parse(this.data_obj.lbl);

      ae_obj["m2m:ae"].api = this.data_obj.api;
      ae_obj["m2m:ae"].aei = this.data_obj.aei;
      //ae_obj["m2m:ae"].lbl = ["key1", "key2"];
      ae_obj["m2m:ae"].rr = (this.data_obj.rr === 'true');
      //ae_obj["m2m:ae"].rn = this.res_name;

      this.data_obj["Content-Type"] = "applicaton/json;ty=2";
      this.data_obj["body"] = ae_obj;

      let headers = {};
      headers["X-M2M-RI"] = this.data_obj.X_M2M_RI;
      headers["X-M2M-Origin"] = this.data_obj.X_M2M_Origin;
      headers["Accept"] = this.data_obj.Accept;
      headers["Content-Type"] = this.data_obj["Content-Type"];

      this.req_display_obj = ae_obj;
      this.request_header_change(headers);
      return (this.request_text = JSON.stringify(ae_obj, undefined, 2));
    },


    cnt_print() {
      let cnt_obj = {};
      cnt_obj["m2m:cnt"] = {};
      cnt_obj["m2m:cnt"].rn = this.res_name;
      cnt_obj["m2m:cnt"].lbl = JSON.parse(this.data_obj.lbl);
      cnt_obj["m2m:cnt"].mni = parseInt(this.data_obj.mni);
      cnt_obj["m2m:cnt"].mbs = parseInt(this.data_obj.mbs);

      this.data_obj["Content-Type"] = "applicaton/json;ty=3";
      this.data_obj["body"] = cnt_obj;

      let headers = {};
      headers["X-M2M-RI"] = this.data_obj.X_M2M_RI;
      headers["X-M2M-Origin"] = this.data_obj.X_M2M_Origin;
      headers["Accept"] = this.data_obj.Accept;
      headers["Content-Type"] = this.data_obj["Content-Type"];

      this.req_display_obj = cnt_obj;
      this.request_header_change(headers);
      return (this.request_text = JSON.stringify(
        this.req_display_obj,
        undefined,
        2
      ));
    },


    cin_print() {
      let cin_obj = {};
      cin_obj["m2m:cin"] = {};
      cin_obj["m2m:cin"].rn = this.res_name;
      cin_obj["m2m:cin"].lbl = JSON.parse(this.data_obj.lbl);
      cin_obj["m2m:cin"].con = this.data_obj.con;

      this.data_obj["Content-Type"] = "applicaton/json;ty=4";
      this.data_obj["body"] = cin_obj;

      let headers = {};
      headers["X-M2M-RI"] = this.data_obj.X_M2M_RI;
      headers["X-M2M-Origin"] = this.data_obj.X_M2M_Origin;
      headers["Accept"] = this.data_obj.Accept;
      headers["Content-Type"] = this.data_obj["Content-Type"];

      this.req_display_obj = cin_obj;
      this.request_header_change(headers);

      return (this.request_text = JSON.stringify(
        this.req_display_obj,
        undefined,
        2
      ));
    },


    sub_print() {
      let sub_obj = {};
      sub_obj["m2m:sub"] = {};
      sub_obj["m2m:sub"].rn = "sub";
      sub_obj["m2m:sub"].enc = {};
      sub_obj["m2m:sub"].enc.net = JSON.parse(this.data_obj.enc);
      sub_obj["m2m:sub"].exc = 0;
      sub_obj["m2m:sub"].rn = this.res_name;
      sub_obj["m2m:sub"].lbl = JSON.parse(this.data_obj.lbl);
      //sub_obj["m2m:sub"].nu = ["http://127.0.0.1:8369"];
      sub_obj["m2m:sub"].nu = ["http://127.0.0.1:8369"];
      this.data_obj["Content-Type"] = "applicaton/json;ty=23";
      this.data_obj["body"] = sub_obj;

      let headers = {};
      headers["X-M2M-RI"] = this.data_obj.X_M2M_RI;
      headers["X-M2M-Origin"] = this.data_obj.X_M2M_Origin;
      headers["Accept"] = this.data_obj.Accept;
      headers["Content-Type"] = this.data_obj["Content-Type"];

      this.req_display_obj = sub_obj;
      this.request_header_change(headers);

      return (this.request_text = JSON.stringify(
        this.req_display_obj,
        undefined,
        2
      ));
    },

    post_request() {
      let url =
        "http://" + this.data_obj.Platform_addr + "/" + this.data_obj.Res_Id;
      const headers = {};
      headers["X-M2M-RI"] = this.data_obj.X_M2M_RI;
      headers["X-M2M-Origin"] = this.data_obj.X_M2M_Origin;
      headers["Content-Type"] = this.data_obj["Content-Type"];
      headers["Accept"] = this.data_obj.Accept;


      let body = this.data_obj.body;
      axios
        .post(url, body, { headers })
        .then((response) => {
          this.res_mess = response.data;
          this.res_status = response.status;
          let headers = {};
          headers["X-M2M-RI"] = response.headers["x-m2m-ri"];
          headers["X-M2M-RSC"] = response.headers["x-m2m-rsc"];
          headers["X-M2M-RVI"] = response.headers["x-m2m-rvi"];
          headers["Content-Length"] = response.headers["content-length"];
          headers["Content-Type"] = response.headers["content-type"];
          this.response_header_change(headers);

          return (this.response_text = JSON.stringify(
            this.res_mess,
            undefined,
            2
          ));
        })
        .catch((error) => {
          this.res_errmess = error.response.data;
          if (error.response.status === 409) {
            this.res_status = error.response.status;
          } else if (error.response.status === 404) {
            this.res_status = error.response.status;
          }
          let headers = {};
          headers["X-M2M-RI"] = error.response.headers["x-m2m-ri"];
          headers["X-M2M-RSC"] = error.response.headers["x-m2m-rsc"];
          headers["X-M2M-RVI"] = error.response.headers["x-m2m-rvi"];
          headers["Content-Length"] = error.response.headers["content-length"];
          headers["Content-Type"] = error.response.headers["content-type"];
          this.response_header_change(headers);

          return (this.response_text = this.res_errmess);
        });
    },

  },
};
</script>

