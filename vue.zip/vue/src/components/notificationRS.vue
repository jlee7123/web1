<template>
  <b-container>
    <h2 class="text-center">Notification Message Viewer</h2>
     <br><br>

    <br>
    <h3>Notification Receiver (HTTP)</h3>

<b-row>
    <b-col>
        <b-form-input label="Port" v-model="port" placeholder="Enter Port Number"></b-form-input>   
    </b-col>
          <b-col>
              <v-btn color="blue" block outlined raised rounded
              variant="success"
              type="button"
              class="conn-btn"
              :disabled="this.connected"
              @click="connSubmit"> {{ connected ? 'START RECEIVE' : 'START RECEIVE' }}  </v-btn>
          </b-col>
          <b-col>
              <v-btn color="pink" block outlined raised rounded
              variant="danger" 
              type="button" 
              class="conn-btn" 
              @click="closeSubmit"> 
              STOP RECEIVE </v-btn>
          </b-col>
        </b-row>  
<br>

    <b-row>
      <br>
      <v-card class="pa-10" outlined shaped elevation="2">
            
        <div class="emq-title">
          <h5>Notification Message (Primitive Content parameter only)</h5>
        </div>
<br>
          <b-form-textarea id="textres" v-model="response_text" rows="20" max-rows="20"></b-form-textarea>


      </v-card>
    </b-row>
  </b-container>
</template>

<script>
import axios from "axios"
import {mixin as VueTimers} from 'vue-timers'
import mqtt from "mqtt";
import {nanoid} from "nanoid";


export default {
    data() {
      return {
        response_text: "",
        connected:false,
        rev_connted:false,
        //host: '127.0.0.1',
        //port: '8369',
        host: '203.253.128.177',
        port: '7579',


        //test 해본 포트 : host: '203.253.128.177', port: '7579',

            client: {
                connected: false,
                loading: false
            },
            connection: {
                host: 'localhost',
                port: 8883,
                endpoint: '',
                clean: true,
                connectTimeout: 4000,
                reconnectPeriod: 4000,
                clientId: 'jiho_' + nanoid(15),
                username: 'keti_muv',
                password: 'keti_muv',
            },





      }
    },
    mixins: [VueTimers],
    timers: {
          getData:{time:1000, repeat:true}
    },
    methods:{

              onMessageHandler(topic, message) {
            let chkTopic = topic.substr(0, 7);

            if (chkTopic === '/oneM2M') {
                var jsonObj = JSON.parse(message.toString());

                if (jsonObj['m2m:rqp'] == null) {
                    jsonObj['m2m:rqp'] = jsonObj;
                }

                if (Object.prototype.hasOwnProperty.call(jsonObj['m2m:rqp'], 'pc')) {

                    // console.log(Object.keys(jsonObj['m2m:rqp'].pc)[0]);
                    // console.log(jsonObj['m2m:rqp'].pc);

                    let arr_topic = topic.split('/');
                    let resp_topic = topic.replace('/req/', '/resp/');
                    let rsp_message = {};
                    rsp_message['m2m:rsp'] = {};
                    rsp_message['m2m:rsp'].rsc = 2001;
                    rsp_message['m2m:rsp'].to = '';
                    rsp_message['m2m:rsp'].fr = arr_topic[4];
                    rsp_message['m2m:rsp'].rqi = '12345';
                    rsp_message['m2m:rsp'].pc = '';

                    //console.log(resp_topic);

                    this.doPublish(resp_topic, JSON.stringify(rsp_message['m2m:rsp']));

                    rsp_message = null;

//sgn - noti > jsonObj print
                    if (Object.prototype.hasOwnProperty.call(jsonObj['m2m:rqp'].pc, 'm2m:sgn')) {
                        if (Object.prototype.hasOwnProperty.call(jsonObj['m2m:rqp'].pc['m2m:sgn'], 'nev')) {
                            if (Object.prototype.hasOwnProperty.call(jsonObj['m2m:rqp'].pc['m2m:sgn'].nev, 'rep')) {

                              //cin noti
                                if (Object.keys(jsonObj['m2m:rqp'].pc['m2m:sgn'].nev.rep)[0] === 'm2m:cin') {
                                    let mission_payload = {};

                                    mission_payload.drone_name = arr_topic[4];
                                    mission_payload.payload = {}
                                    mission_payload.payload.sur = jsonObj['m2m:rqp'].pc['m2m:sgn'].sur;
                                    mission_payload.payload.con = jsonObj['m2m:rqp'].pc['m2m:sgn'].nev.rep['m2m:cin'].con;

                                    //this.$store.commit('setMissionPayload', mission_payload);

                                    //EventBus.$emit('push-mission-' + mission_payload.drone_name, mission_payload.payload);

                                    let payload = JSON.parse(JSON.stringify(mission_payload.payload));
                                    mission_payload = null;
                                    let arr_sur = payload.sur.split('/');
                                    arr_sur.pop();
                                    payload.sur = '/' + arr_sur.join('/');

                                    //if ((this.missionLteUrl + '/' + this.sortie_name) === payload.sur) {
                                    if (this.missionLteUrl === payload.sur) {
                                        // console.log(payload.sur);

                                        if (Object.prototype.hasOwnProperty.call(payload.con, 'rsrp')) {
                                            this.colorLteVal = '#9E9E9E';

                                            this.curLteVal = payload.con.rsrp;
                                            //console.log(this.curLteVal);

                                            payload = null;

                                            if (0 > this.curLteVal && this.curLteVal >= -80) {
                                                this.iconLte = 'mdi-network-strength-4';
                                                this.colorLteVal = '#1E88E5';
                                            }
                                            else if (-80 > this.curLteVal && this.curLteVal >= -90) {
                                                this.iconLte = 'mdi-network-strength-3';
                                                this.colorLteVal = '#76FF03';
                                            }
                                            else if (-90 > this.curLteVal && this.curLteVal >= -100) {
                                                this.iconLte = 'mdi-network-strength-2';
                                                this.colorLteVal = '#FFFF00';
                                            }
                                            else {
                                                this.iconLte = 'mdi-network-strength-1';
                                                this.colorLteVal = '#FF3D00';
                                            }

                                            this.info.colorLteVal = this.colorLteVal;
                                            this.info.curLteVal = this.curLteVal;
                                            this.info.iconLte = this.iconLte;

                                            if (this.lteTimeoutObj) {
                                                clearTimeout(this.lteTimeoutObj);
                                            }

                                            this.lteTimeoutObj = setTimeout(() => {
                                                this.lteTimeoutObj = null;
                                                this.colorLteVal = '#9E9E9E';
                                                this.iconLte = 'mdi-network-strength-off-outline';
                                            }, 5500);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

        },

        doSubscribe(topic) {
            if (this.client.connected) {
                const qos = 0;
                this.client.subscribe(topic, {qos}, (error) => {
                    if (error) {
                        console.log('Subscribe to topics error', error)
                        return
                    }
                    
                });
            }
        },

        doUnSubscribe(topic) {
            if (this.client.connected) {

                this.client.unsubscribe(topic, (error) => {
                    if (error) {
                        console.log('Unsubscribe error', error)
                    }

                   
                    console.log('Unsubscribe to topics (', topic, ')');

                    
                });
            }
        },

        doPublish(topic, payload) {
            if (this.client.connected) {
                this.client.publish(topic, payload, 0, error => {
                    if (error) {
                        console.log('Publish error', error)
                    }
                });
            }

            if (this.client.connected) {
                this.client.publish(topic, payload, 0, error => {
                    if (error) {
                        console.log('Publish error', error)
                    }
                });
            }
        },

              createConnection() {
            if (this.client.connected) {
                console.log('DroneInfo', this.name, 'createConnection', 'destroyConnection')
                this.destroyConnection();
            }

            if (!this.client.connected) {

                this.client.loading = true;
                this.connection.clientId = 'mqttjs_' + 'jiho' + '_' + nanoid(15);
                //this.connection.host = 'localhost';
                this.connection.host = '203.253.128.177';
                const {host, port, endpoint, ...options} = this.connection;
                const connectUrl = `ws://${host}:${port}${endpoint}`
                try {
                    this.client = mqtt.connect(connectUrl, options);

                    this.client.on('connect', () => {
                        console.log(this.name, host, 'Connection succeeded!');

                        this.client.connected = true;
                        this.client.loading = false;

                        //localStorage.setItem('mqttConnection-' + this.name, JSON.stringify(this.client));


                        let subtopic = '/oneM2M/req/Mobius2/' + 'Sjiho' + '/#';
                        this.doUnSubscribe(subtopic);

                        setTimeout(() => {
                            this.doSubscribe(subtopic);
                            console.log('Subscribe to ', subtopic);
                        }, 200);
                    });

                    this.client.on('error', (error) => {
                        console.log('Connection failed', error);

                        this.destroyConnection();
                    });

                    this.client.on('close', () => {
                        console.log('Connection closed');

                        this.destroyConnection();

                        this.connection.clientId = 'mqttjs_' + this.name + '_' + nanoid(15);
                    });

                    this.client.on('message', (topic, message) => {
                        // this.receiveNews = this.receiveNews.concat(message)
                        console.log(`Received message ${message} from topic ${topic}`);

                        //console.log(topic.split('/')[4], message.toString());

                        let payload = {};
                        payload.topic = topic;
                        payload.message = message;

                        this.onMessageHandler(payload.topic, payload.message);
                    });
                }
                catch (error) {
                    console.log('mqtt.connect error', error);
                    this.client.connected = false;
                }
            }
        },

        destroyConnection() {
            if (this.client.connected) {
                try {
                    if(Object.hasOwnProperty.call(this.client, '__ob__')) {
                        this.client.end();
                    }

                    this.client = {
                        connected: false,
                        loading: false
                    };

                    console.log(this.name, 'Successfully disconnected!');

                    //localStorage.setItem('mqttConnection-' + this.name, JSON.stringify(this.client));
                }
                catch (error) {
                    this.client = {
                        connected: false,
                        loading: false
                    };
                    //localStorage.setItem('mqttConnection-' + this.name, JSON.stringify(this.client));

                    console.log('Disconnect failed', this.name, error.toString());
                }
            }
        },

      sub_print () {
        let sub_obj = {};
        sub_obj["m2m:sub"] ={}
        sub_obj["m2m:sub"].rn = "sub"
        sub_obj["m2m:sub"].enc = {}
        sub_obj["m2m:sub"].enc.net = [3]

        sub_obj["m2m:sub"].rn = this.res_name 
        sub_obj["m2m:sub"].nu = ["http://127.0.0.1/3000"]
        //sub_obj["m2m:sub"].nu = ["http://203.253.128.177:7579"];
        this.data_obj["Content-Type"] = 'applicaton/json;ty=23'
        this.data_obj["body"] = sub_obj
        return this.request_text = JSON.stringify(this.data_obj, undefined, 2)
      },
      post_request(){
        let url = "http://" + this.data_obj.Platform_addr + "/" + this.data_obj.Res_Id
        const headers = {}
        headers["X-M2M-RI"] = this.data_obj.X_M2M_RI
        headers["X-M2M-Origin"] = this.data_obj.X_M2M_Origin
        headers["Accept"] = this.data_obj.Accept
        headers["Content-Type"] = this.data_obj["Content-Type"]
        
        let body = this.data_obj.body
        axios.post(url, body, { headers })
          .then(response =>{
            this.res_mess = response.data;
            console.log(this.res_mess, response.status);
            let res_obj = {}
            res_obj.status = response.status
            res_obj.Body = this.res_mess

            return this.response_text = JSON.stringify(res_obj, undefined, 2)
          })
          .catch(error => {
            this.res_errmess = error.message
            return this.response_text = this.res_errmess
          });
      },



      connSubmit () {
      
          this.connected = true;
          axios.post('http://localhost:3000/notion', {
        
          host: this.host,
          port: this.port
      })
        .then((response) => {
          this.output = response.data
        })
        .catch((error) => {
          this.output = error
        })
      },
      closeSubmit () {
          if(this.rev_connted==true){
            this.$timers.stop('getData')
          }
          this.connected = false
          axios.post('http://localhost:3000/noticlose', {
          
          })
            .then((response) => {
              this.output = response.data
            })
            .catch((error) => {
              this.output = error
            })
      },
    getData() {
        axios.get('http://localhost:3000/getdata')
          .then((response) => {
          console.log(response.data);
          return this.response_text = JSON.stringify(response.data, undefined, 2)
        })
    },
    recv_start(){
        this.$timer.start('getData')
        this.rev_connted = true
    },
    recv_stop(){
        this.$timer.stop('getData')
        this.rev_connted = false
    }
  },
  created(){
    this.createConnection();
  },

  beforeDestroy() {
        this.destroyConnection();
  }

}
</script>