<template>
  <div class="footer">
    <h1>&nbsp;</h1>
    <br />
  </div>
</template>